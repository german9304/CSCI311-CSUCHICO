
#ifndef MSTAPP_H
#define MSTAPP_H

#include "graph.h"

class MSTapp{
public:
    int main();
    void readGraph();

private:
    Graph myGrap();
};

#endif /* mstapp_h */
